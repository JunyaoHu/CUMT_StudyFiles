package com.hujunyao.cumtorder.utils;
public class Constant {
    public static final String WEB_SITE = "http://10.3.109.193:8080/order";//内网接口
    public static final String REQUEST_SHOP_URL = "/shop_list_data.json";  //店铺列表接口
}
