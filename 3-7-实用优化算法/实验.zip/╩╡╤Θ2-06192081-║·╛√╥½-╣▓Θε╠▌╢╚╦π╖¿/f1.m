function f= f1(x)
f = (1-x(1))^2+2*(x(2)-x(1)^2)^2;
end