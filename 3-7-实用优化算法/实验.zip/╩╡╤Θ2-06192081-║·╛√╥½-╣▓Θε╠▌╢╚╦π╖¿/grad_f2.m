function gf = grad_f2(x)
gf = [x(1)^3 - x(2) + 1;
    x(2) - x(1) - 1];
end