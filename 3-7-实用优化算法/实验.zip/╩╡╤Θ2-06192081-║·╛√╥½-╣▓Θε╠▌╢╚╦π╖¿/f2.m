function f= f2(x)
f = 0.25*x(1)^4+0.5*x(2)^2-x(1)*x(2)+x(1)-x(2);
end