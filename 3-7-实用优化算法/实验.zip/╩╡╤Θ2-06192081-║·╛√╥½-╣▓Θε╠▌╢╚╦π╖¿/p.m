function px = p(func, alp, x, d)
px = func(x+alp*d);
end