function gcx = grad_st_f1(x)
gcx1 = [2*x(1); -1];
gcx = [gcx1];
end