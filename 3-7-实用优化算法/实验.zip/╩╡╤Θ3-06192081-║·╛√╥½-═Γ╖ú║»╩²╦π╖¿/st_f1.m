function cx = st_f1(x)
cx1 = x(1)^2-x(2);
cx = [cx1];
end