function f= f1(x)
f = (x(1)-2)^4+(x(1)-2*x(2))^2;
end