function px = p(funf, func, sigma, alp, x, d)
px = funp(funf, func,x+alp*d,sigma);
end