function cx = st_f2(x)
cx1 = x(1)+2*x(2)+x(3)-4;
cx = [cx1];
end