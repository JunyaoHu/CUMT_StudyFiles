function gcx = grad_st_f2(x)
gcx1 = [1;2;1];
gcx = [gcx1];
end