function y = f2(x)
y = exp(-x) + exp(x);
end