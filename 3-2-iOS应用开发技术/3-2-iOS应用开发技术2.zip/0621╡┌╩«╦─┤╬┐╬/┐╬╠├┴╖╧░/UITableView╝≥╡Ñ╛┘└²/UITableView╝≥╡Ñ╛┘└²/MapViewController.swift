//
//  MapViewController.swift
//  UITableView简单举例
//
//  Created by xuhui on 2022/6/14.
//  Copyright © 2022 xuhui. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController, MKMapViewDelegate {

    var area: Area1MO!
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let coder = CLGeocoder()
        coder.geocodeAddressString(area.name!) { (ps, error) in
            guard let ps = ps else{
                print(error ?? "未知错误")
                return
            }
            let place = ps.first
            let annotation = MKPointAnnotation()
            annotation.title = self.area.name
            //annotation.subtitle = self.area.province
            if let loc = place?.location{
                annotation.coordinate = loc.coordinate
                self.mapView.showAnnotations([annotation], animated: true)
                self.mapView.selectAnnotation(annotation, animated: true)
            }
        }
        // Do any additional setup after loading the view.
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let id = "myid"
        var av = mapView.dequeueReusableAnnotationView(withIdentifier: id)
        if av == nil{
            av = MKPinAnnotationView(annotation: annotation, reuseIdentifier: id)
            av?.canShowCallout = true
        }
        let leftIconView = UIImageView(frame: CGRect(x: 0, y: 0, width: 53, height: 53))
        leftIconView.image = UIImage(data: area.image as! Data)
        av?.leftCalloutAccessoryView = leftIconView
        
        return av
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
