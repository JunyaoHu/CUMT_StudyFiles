//
//  AreaTableViewController.swift
//  UITableView简单举例
//
//  Created by xuhui on 2022/5/26.
//  Copyright © 2022 xuhui. All rights reserved.
//

import UIKit

class AreaTableViewController: UITableViewController {

    var areas: [Area1MO] = []
    
//    var areas = [Area(name: "中国矿业大学江苏省徐州市泉山区大学路1号中国矿业大学南湖校区计算机学院计A309-2", province:"江苏省", part: "华东", image:"xuzhou", isVisited: false) ,
//     Area(name: "山东大学济南市山大南路 27 号", province:"山东省", part: "华东", image:"jinan", isVisited: false) ,
//     Area(name: "河北大学保定市五四东路180号", province:"河北省", part: "华北", image:"shijiazhuang", isVisited: false),
//     Area(name: "武汉大学武汉市珞珈山街道八一路299号", province:"湖北省", part: "华中", image:"wuhan", isVisited: false) ,
//     Area(name: "湖南大学长沙市岳麓区麓山南路麓山门", province:"湖南省", part: "华中", image:"changsha", isVisited: false) ,
//    Area(name: "海南大学三亚学院三亚市迎宾大道学院路", province:"海南省", part: "华南", image:"sanya", isVisited: false) ,
//    Area(name: "浙江大学西湖区浙大路38号 ", province:"浙江省", part: "华东", image:"hangzhou", isVisited: false) ,
//    Area(name: "中国科学技术大学合肥市金寨路96号", province:"安徽省", part: "华东", image:"hefei", isVisited: false) ,
//    Area(name: "广西师范大学桂林市育才路15号", province:"广西省", part: "广西", image:"guilin", isVisited: false) ,
//    Area(name: "中山大学广州市新港西路135号", province:"广东省", part: "华南", image:"guangzhou", isVisited: false)]
   
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.estimatedRowHeight = 80
        tableView.rowHeight = UITableView.automaticDimension

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func viewDidAppear(_ animated: Bool) {
        fetchAllData()
        tableView.reloadData()
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return areas.count
    }
    
    func fetchAllData()  {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        do {
            areas = try appDelegate.persistentContainer.viewContext.fetch(Area1MO.fetchRequest())
        } catch  {
            print(error)
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! Custom_TableViewCell

       cell.thumbImageView.image = UIImage(data: areas[indexPath.row].image as! Data)
        cell.nameLabel.text = areas[indexPath.row].name
        cell.provinceLabel.text = areas[indexPath.row].province
        cell.partLabel.text = areas[indexPath.row].part
        if areas[indexPath.row].isVisited {
            cell.accessoryType = .checkmark
        }else{
            cell.accessoryType = .none
        }
        
        cell.thumbImageView.layer.cornerRadius = cell.thumbImageView.frame.size.width/2
        
        cell.thumbImageView.clipsToBounds = true

        return cell
    }
    
   // MARK: - Table view delegate
//    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let menu = UIAlertController(title: "您好", message: "您选择了第\(indexPath.row)行", preferredStyle: .actionSheet)
//        let option1 = UIAlertAction(title: "取消", style: .cancel, handler: nil)
//        let option2 = UIAlertAction(title: "我去过", style: .default) { (_) in
//            let cell = tableView.cellForRow(at: indexPath)
//            cell?.accessoryType = .checkmark
//            self.visited[indexPath.row] = true
//            }
//        
//        menu.addAction(option1)
//        menu.addAction(option2)
//        
//        self.present(menu, animated: true, completion: nil)
//    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
//    // Override to support editing the table view.
//    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .delete {
//            // Delete the row from the data source
//            areaImages.remove(at: indexPath.row)
//            areas.remove(at: indexPath.row)
//            provinces.remove(at: indexPath.row)
//            parts.remove(at: indexPath.row)
//            visited.remove(at: indexPath.row)
//
//            tableView.deleteRows(at: [indexPath], with: .fade)
//            //tableView.reloadData()
//        } else if editingStyle == .insert {
//            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
//        }
//    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let actionShare = UITableViewRowAction(style: .normal, title: "分享") { (_, indexPath) in
        }
        
        actionShare.backgroundColor = UIColor.orange
        
        let actionDel = UITableViewRowAction(style: .destructive, title: "删除") { (_, indexPath) in
            self.areas.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
        
        actionDel.backgroundColor = UIColor(red: 62/255, green: 125/255, blue: 125/255, alpha: 1)
        
        return [actionShare, actionDel]
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "showAreaDetail"{
            let dest = segue.destination as! DetailTableViewController
            dest.area = areas[(tableView.indexPathForSelectedRow?.row)!]
        }
    }
    
    @IBAction func close(segue: UIStoryboardSegue){
        
    }

}
