//
//  WebViewController.swift
//  UITableView简单举例
//
//  Created by xuhui on 2022/6/28.
//  Copyright © 2022 xuhui. All rights reserved.
//

import UIKit
import WebKit

class WebViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let wkWebView = WKWebView(frame: view.frame)
        view.addSubview(wkWebView)
        
        if let url = URL(string: "https://www.baidu.com") {
            let request = URLRequest(url: url)
            wkWebView.load(request)
        }

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
