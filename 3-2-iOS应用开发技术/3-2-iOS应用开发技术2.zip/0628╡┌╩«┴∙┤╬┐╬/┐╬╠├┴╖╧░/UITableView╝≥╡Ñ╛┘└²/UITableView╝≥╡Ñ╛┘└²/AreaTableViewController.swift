//
//  AreaTableViewController.swift
//  UITableView简单举例
//
//  Created by xuhui on 2022/5/26.
//  Copyright © 2022 xuhui. All rights reserved.
//

import UIKit
import CoreData

class AreaTableViewController: UITableViewController, NSFetchedResultsControllerDelegate, UISearchResultsUpdating {
   
    func updateSearchResults(for searchController: UISearchController) {
        if let text = searchController.searchBar.text {
            searchFilter(text: text)
            tableView.reloadData()
        }
    }
    

    var areas: [Area1MO] = []
    var fc: NSFetchedResultsController<Area1MO>!
    var sc: UISearchController!
    var searchResult: [Area1MO] = []
   
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.estimatedRowHeight = 80
        tableView.rowHeight = UITableView.automaticDimension
        fetchAllData2()
        
        sc = UISearchController(searchResultsController: nil)
        sc.searchResultsUpdater = self
        tableView.tableHeaderView = sc.searchBar
        sc.dimsBackgroundDuringPresentation = false
        
        sc.searchBar.searchBarStyle = .minimal
        sc.searchBar.placeholder = "请输入地名进行搜索"

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sc.isActive = false
    }
    
//    override func viewDidAppear(_ animated: Bool) {
//        fetchAllData()
//        tableView.reloadData()
//    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return  sc.isActive ? searchResult.count : areas.count
    }
    
//    func fetchAllData()  {
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        do {
//            areas = try appDelegate.persistentContainer.viewContext.fetch(Area1MO.fetchRequest())
//        } catch  {
//            print(error)
//        }
//    }
    
    func fetchAllData2()  {
        let request: NSFetchRequest = Area1MO.fetchRequest()
        let sd = NSSortDescriptor(key: "name", ascending: true)
        request.sortDescriptors = [sd]
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        fc = NSFetchedResultsController(fetchRequest: request, managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
        fc.delegate = self
        do {
            try fc.performFetch()
            if let object = fc.fetchedObjects {
                areas = object
            }
        } catch  {
            print(error)
        }
    }
    
    func searchFilter(text: String)  {
        searchResult = areas.filter({ (area) -> Bool in
            return(area.name!.localizedCaseInsensitiveContains(text))
        })
    }
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.beginUpdates()
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.endUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .delete:
            tableView.deleteRows(at: [indexPath!], with: .automatic)
        case .insert:
            tableView.insertRows(at: [newIndexPath!], with: .automatic)
        case .update:
            tableView.reloadRows(at: [indexPath!], with: .automatic)
        default:
            tableView.reloadData()
        }
        if let object = controller.fetchedObjects {
            areas = object as! [Area1MO]
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! Custom_TableViewCell
        
        let area = sc.isActive ? searchResult[indexPath.row] : areas[indexPath.row]

       cell.thumbImageView.image = UIImage(data: area.image as! Data)
        cell.nameLabel.text = area.name
        cell.provinceLabel.text = area.province
        cell.partLabel.text = area.part
        if area.isVisited {
            cell.accessoryType = .checkmark
        }else{
            cell.accessoryType = .none
        }
        
        cell.thumbImageView.layer.cornerRadius = cell.thumbImageView.frame.size.width/2
        
        cell.thumbImageView.clipsToBounds = true

        return cell
    }
    
   // MARK: - Table view delegate
//    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let menu = UIAlertController(title: "您好", message: "您选择了第\(indexPath.row)行", preferredStyle: .actionSheet)
//        let option1 = UIAlertAction(title: "取消", style: .cancel, handler: nil)
//        let option2 = UIAlertAction(title: "我去过", style: .default) { (_) in
//            let cell = tableView.cellForRow(at: indexPath)
//            cell?.accessoryType = .checkmark
//            self.visited[indexPath.row] = true
//            }
//        
//        menu.addAction(option1)
//        menu.addAction(option2)
//        
//        self.present(menu, animated: true, completion: nil)
//    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
//    // Override to support editing the table view.
//    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .delete {
//            // Delete the row from the data source
//            areaImages.remove(at: indexPath.row)
//            areas.remove(at: indexPath.row)
//            provinces.remove(at: indexPath.row)
//            parts.remove(at: indexPath.row)
//            visited.remove(at: indexPath.row)
//
//            tableView.deleteRows(at: [indexPath], with: .fade)
//            //tableView.reloadData()
//        } else if editingStyle == .insert {
//            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
//        }
//    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let actionShare = UITableViewRowAction(style: .normal, title: "分享") { (_, indexPath) in
        }
        
        actionShare.backgroundColor = UIColor.orange
        
        let actionDel = UITableViewRowAction(style: .destructive, title: "删除") { (_, indexPath) in
//            self.areas.remove(at: indexPath.row)
//            tableView.deleteRows(at: [indexPath], with: .fade)
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            context.delete(self.fc.object(at: indexPath))
            appDelegate.saveContext()
        }
        
        actionDel.backgroundColor = UIColor(red: 62/255, green: 125/255, blue: 125/255, alpha: 1)
        
        return [actionShare, actionDel]
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "showAreaDetail"{
            let dest = segue.destination as! DetailTableViewController
            dest.area = sc.isActive ? searchResult[(tableView.indexPathForSelectedRow?.row)!] : areas[(tableView.indexPathForSelectedRow?.row)!]
        }
    }
    
    @IBAction func close(segue: UIStoryboardSegue){
        
    }

}
