//
//  Custom–TableViewCell.swift
//  UITableView简单举例
//
//  Created by xuhui on 2022/5/26.
//  Copyright © 2022 xuhui. All rights reserved.
//

import UIKit

class Custom_TableViewCell: UITableViewCell {

    @IBOutlet weak var thumbImageView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var provinceLabel: UILabel!
    
    @IBOutlet weak var partLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
