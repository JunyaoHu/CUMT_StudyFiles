//
//  Area.swift
//  UITableView简单举例
//
//  Created by xuhui on 2022/6/2.
//  Copyright © 2022 xuhui. All rights reserved.
//

import Foundation

struct Area {
    var name: String
    var province: String
    var part: String
    var image: String
    var isVisited: Bool
    var rating = ""
    
    init(name: String, province: String, part: String, image: String, isVisited: Bool){
        self.name = name
        self.province = province
        self.part = part
        self.image = image
        self.isVisited = isVisited
    }
}
