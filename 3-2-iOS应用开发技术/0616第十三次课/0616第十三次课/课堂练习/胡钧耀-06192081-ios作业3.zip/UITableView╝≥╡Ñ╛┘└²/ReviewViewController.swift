//
//  ReviewViewController.swift
//  UITableView简单举例
//
//  Created by xuhui on 2022/6/9.
//  Copyright © 2022 xuhui. All rights reserved.
//

import UIKit

class ReviewViewController: UIViewController {
    var imgname: String!
    var rating: String?
    
    @IBOutlet weak var bgImageView: UIImageView!
    @IBOutlet weak var ratingStackView: UIStackView!

    @IBAction func ratingTpa(_ sender: UIButton) {
//        switch sender.tag {
//        case 100:
//            rating = "dislike"
//        case 101:
//            rating = "general"
//        case 102:
//            rating = "good"
//        default:
//            break
//        }
        rating = sender.titleLabel?.text
        
        performSegue(withIdentifier: "unwindToDetailView", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        bgImageView.image = UIImage(named: imgname)
        let effect = UIBlurEffect(style: .light)
        let effectView = UIVisualEffectView(effect: effect)
        effectView.frame = view.frame
        bgImageView.addSubview(effectView)
        
        let startPos = CGAffineTransform(translationX: 0, y: 500)
        let startScale = CGAffineTransform(scaleX: 0, y: 0)
        ratingStackView.transform = startScale.concatenating(startPos)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.3, initialSpringVelocity: 0.5, options: [], animations: {
            
            let endPos = CGAffineTransform(translationX: 0, y: 0)
            let endScale = CGAffineTransform.identity
            self.ratingStackView.transform = endScale.concatenating(endPos)
            
        }, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
