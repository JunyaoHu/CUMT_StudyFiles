#include <iostream>
using namespace std
int main()
{
    int b = 3 + 131;
    // comment1
    if (b) {
        cout << "Hello! " << endl;
        /*
        comment2
        123 456 int
        */
    }
    else {
        cout << "Welcome to c++! " << endl;
    }
    return 0;
}

