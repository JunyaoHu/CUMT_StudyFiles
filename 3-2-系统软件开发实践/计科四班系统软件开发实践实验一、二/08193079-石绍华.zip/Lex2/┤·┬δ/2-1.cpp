if(a==2){
	a=a+23;
}else{
	b03=23;
}

return 0;
