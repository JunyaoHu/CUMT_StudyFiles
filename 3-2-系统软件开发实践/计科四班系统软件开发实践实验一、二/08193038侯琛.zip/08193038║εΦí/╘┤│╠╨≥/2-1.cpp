#include <iostream>
using namespace std
int main()
{
	float a = 4.90867e-2;
	int b = 0xE124;
	int c = 0167;
	// comment1
	cout << "Hello! " << endl;
	/*
	comment2
	123 456 int
	*/
	cout << "Welcome to c++! " << endl;
	return 0;
}