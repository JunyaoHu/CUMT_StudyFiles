#include <iostream>
using namespace std
int main()
{ 
   floar a = 4.90867e-2;
   int b = 0xFE24;
   int c = 0167;
   // comment1
   cout<<"Hello! "<<endl;
   /*
   comment2 
   123 456 int
   */
    cout<<"Welcome to c++! "<<endl;
    return 0;
}
