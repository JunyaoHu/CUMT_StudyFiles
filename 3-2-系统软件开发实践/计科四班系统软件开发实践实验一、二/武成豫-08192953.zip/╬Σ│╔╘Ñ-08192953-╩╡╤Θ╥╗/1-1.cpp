﻿#include iostream
using namespace std
int main
cout "Hello! "<<endl
cout "Welcome to c++! " endl
return