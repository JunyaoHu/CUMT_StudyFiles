#include <iostream>
using namespace std
int main()
{   
    int a =  1.5e-6;
    int b = 064;
    int c = 0x7f;
    // comment1
    cout<<"Hello! "<<endl;
    /*
    comment2 
    123 456 int
    */
    return 0;
}

